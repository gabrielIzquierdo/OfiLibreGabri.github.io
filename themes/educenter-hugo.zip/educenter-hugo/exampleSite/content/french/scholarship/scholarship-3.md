---
title: "GÉNIE CHIMIQUE"
draft: false
# page title background image
bg_image: "images/backgrounds/page-title.jpg"
# scholarship image
image: "images/scholarship/scholarship-item-3.jpg"
# meta description
description : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. dolore magna aliqua. Ut enim ad minim veniam, quis nostrud."
---

* instituts
* Recherche intelligemment affiliée
* Accès numérique aux bourses d’étude
* Catalyse intelligente
* Portail vers une bibliothèque intelligente
* Programmes de recherche intelligente