---
title: "John doe"
# page title background image
bg_image: "images/backgrounds/page-title.jpg"
# meta description
description : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. dolore magna aliqua. Ut enim ad minim veniam, quis nostrud."
email: "email2@example.org"
# portrait
photo: ""
social:
  - icon : "ti-facebook" # themify icon pack : https://themify.me/themify-icons
    link : "#"
  - icon : "ti-twitter-alt" # themify icon pack : https://themify.me/themify-icons
    link : "#"
  - icon : "ti-github" # themify icon pack : https://themify.me/themify-icons
    link : "#"
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sit amet vulputate augue. Duis auctor lacus id vehicula gravida. Nam suscipit vitae purus et laoreet.
Donec nisi dolor, consequat vel pretium id, auctor in dui. Nam iaculis, neque ac ullamcorper.